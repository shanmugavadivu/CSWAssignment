package com.shanmugavadivu.project.jsontoxml;

public interface XMLJSONConverterI {
	
	void createXMLJSONConverter(String jsonfilepath, String xmlfilepath);

}
